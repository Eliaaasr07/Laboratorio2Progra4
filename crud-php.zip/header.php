<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>CRUD PHP</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <header>
        <h1>Gestión de Productos</h1>
        <nav>
            <a href="index.php">Inicio</a>
            <a href="create.php">Agregar Producto</a>
        </nav>
    </header>
    <main>
