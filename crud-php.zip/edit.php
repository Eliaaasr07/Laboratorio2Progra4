<?php
include 'db.php';
include 'header.php';

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM productos WHERE id=$id");
$producto = $result->fetch_assoc();
?>

<h2>Editar Producto</h2>
<form action="update.php" method="POST">
    <input type="hidden" name="id" value="<?= $producto['id'] ?>">
    <input type="text" name="nombre" value="<?= $producto['nombre'] ?>" required><br>
    <textarea name="descripcion" required><?= $producto['descripcion'] ?></textarea><br>
    <input type="number" step="0.01" name="precio" value="<?= $producto['precio'] ?>" required><br>
    <button type="submit">Actualizar</button>
</form>

<?php include 'footer.php'; ?>
