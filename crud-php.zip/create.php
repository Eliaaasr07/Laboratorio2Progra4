<?php include 'header.php'; ?>
<h2>Agregar Producto</h2>
<form action="store.php" method="POST">
    <input type="text" name="nombre" placeholder="Nombre" required><br>
    <textarea name="descripcion" placeholder="Descripción" required></textarea><br>
    <input type="number" step="0.01" name="precio" placeholder="Precio" required><br>
    <button type="submit">Guardar</button>
</form>
<?php include 'footer.php'; ?>
