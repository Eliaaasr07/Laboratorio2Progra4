<?php include 'db.php'; include 'header.php';

$result = $conn->query("SELECT * FROM productos");

if ($result->num_rows > 0): ?>
    <table>
        <tr>
            <th>ID</th><th>Nombre</th><th>Descripción</th><th>Precio</th><th>Acciones</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['nombre'] ?></td>
            <td><?= $row['descripcion'] ?></td>
            <td>$<?= $row['precio'] ?></td>
            <td>
                <a class="btn" href="edit.php?id=<?= $row['id'] ?>">Editar</a>
                <a class="btn btn-danger" href="delete.php?id=<?= $row['id'] ?>" onclick="return confirm('¿Seguro?')">Eliminar</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
<?php else: ?>
    <p>No hay productos.</p>
<?php endif;

include 'footer.php';
?>