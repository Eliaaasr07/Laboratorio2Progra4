    </main>
    <footer>
        <p>&copy; 2025 CRUD en PHP</p>
    </footer>
</body>
</html>
