<?php
include 'db.php';

$id = $_POST['id'];
$nombre = $_POST['nombre'];
$descripcion = $_POST['descripcion'];
$precio = $_POST['precio'];

$conn->query("UPDATE productos SET nombre='$nombre', descripcion='$descripcion', precio='$precio' WHERE id=$id");

header("Location: index.php");
?>